IndieArcade static page
======================

Just open index.html in a browser.
Or drop the folder on Netlify / GitHub Pages / any free host.

Files:
- index.html
- style.css
- script.js

No build step, no frameworks, no AI backend stuff.
Edit whatever you want (add shows, change colors, break things, etc.)

Accent color is #ccff00 (the lime green).
Background is near-black #08080c.
