// search filter
function filterShows() {
  var input = document.getElementById('search');
  var filter = input.value.toLowerCase();
  var cards = document.querySelectorAll('.card');

  for (var i = 0; i < cards.length; i++) {
    var title = cards[i].getAttribute('data-title') || '';
    if (title.indexOf(filter) > -1 || filter === '') {
      cards[i].style.display = '';
    } else {
      cards[i].style.display = 'none';
    }
  }
}

// play a show
function playShow(ytId, name, credit) {
  var section = document.getElementById('player-section');
  var iframe = document.getElementById('yt-player');
  var titleEl = document.getElementById('now-playing');
  var creditEl = document.getElementById('credit-line');

  // regular youtube embed (nocookie often triggers Error 153 on local / some browsers)
  var embedUrl = 'https://www.youtube.com/embed/' + ytId + '?autoplay=1&rel=0&modestbranding=1';
  iframe.src = embedUrl;

  titleEl.textContent = name || 'Now playing';

  var ytLink = 'https://www.youtube.com/watch?v=' + ytId;
  creditEl.innerHTML = (credit ? 'Source: ' + credit + ' • ' : '') +
    '<a href="' + ytLink + '" target="_blank" rel="noopener" style="color:#ccff00;">Open on YouTube</a>';

  section.style.display = 'block';
  section.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

function closePlayer() {
  var section = document.getElementById('player-section');
  var iframe = document.getElementById('yt-player');
  iframe.src = ''; // stop video
  section.style.display = 'none';
}

// click handlers on cards
document.querySelectorAll('.card').forEach(function(card) {
  card.addEventListener('click', function() {
    var yt = this.getAttribute('data-yt');
    var name = this.getAttribute('data-name');
    var credit = this.getAttribute('data-credit');
    if (yt) {
      playShow(yt, name, credit);
    }
  });
});

console.log('IndieArcade static page — plain HTML/CSS/JS + YouTube embeds');
